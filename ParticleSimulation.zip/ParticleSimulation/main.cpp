#include <SFML/Graphics.hpp>
#include "Particle.h"
#include "utilisF.h"


int main()
{
    //benchmark related
    sys_time_t timeAtStartFrame;
    sys_time_t timeAtEndFrame;
    sf::String realFps = "0";
    sf::Font font;
    font.loadFromFile("C:\\GameDevlopment\\Fonts\\Arial\\ARIAL.TTF");
    sf::Text actualFps;
    actualFps.setFont(font);
    actualFps.setCharacterSize(20);
    actualFps.setFillColor(sf::Color::Red);

    //initialization of window 
    unsigned int fps = 60;
    sf::RenderWindow window(sf::VideoMode(1600, 900), "Particle System");
    u_InitWindow(window, fps);

    //variables
    float dt = 1.f / fps;
    int particleAmount = 5;

    //initialization of boundary and particles objects
    std::vector<Particle*> particles;
    Boundary* boundary = new Boundary(window.getSize().x /2, window.getSize().y /2, 1200, 800, 100);
    std::vector<sf::CircleShape> particlesShape;
    sf::RectangleShape bound;

    //creating particles and boundary
    u_CreateParticles(particles, boundary, particleAmount);
    u_CreateParticlesShape(particlesShape, particles);
    u_CreateBoundaryShape(bound, boundary);

    //main window loop
    while (window.isOpen())
    {
        //just for benchmarking
        system_time(&timeAtStartFrame);
        long long startTime = time_to_msec(timeAtStartFrame);

        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }
        //Logic here
        u_ParticlesUpdate(particles, boundary, dt);
        //u_CreateParticlesShape(particlesShape, particles);
        u_UpdateParticlesShape(particlesShape, particles);


        //Visual here
        window.clear();
        window.draw(bound);
        for (sf::CircleShape p : particlesShape) {
            window.draw(p);
        }

        //benchmarking
        system_time(&timeAtEndFrame);
        long long endTime = time_to_msec(timeAtEndFrame);
        realFps = std::to_string(endTime - startTime);
        actualFps.setString("ms: " + realFps);
        window.draw(actualFps);

        window.display();
    }

    return 0;
}
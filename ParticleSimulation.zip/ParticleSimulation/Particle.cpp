#include "Particle.h"
#include <iostream>
//Color Related
u_Color::u_Color(int r, int g, int b) :
	r(r), g(g), b(b) {}

//Vector Related
u_vec2d::u_vec2d() :
	x(0), y(0) {}
u_vec2d::u_vec2d(float x, float y) :
	x(x), y(y) {}

//Boundary Related 
Boundary::Boundary(float x, float y, float width, float height, float mass) :
	x(x), y(y), width(width), height(height), mass(mass) {}


//Particle Related Initialization and Definitions
Particle::Particle(float x, float y) :
	pos(u_vec2d(x,y)), radius(10.f), color(u_Color(50, 150, 255)), vel(u_vec2d()), mass(0) {}
Particle::Particle(float x, float y, float radius) :
	pos(u_vec2d(x, y)), radius(radius), color(u_Color(50, 150, 255)), vel(u_vec2d()), mass(0) {}
Particle::Particle(float x, float y, float radius, u_Color* col, u_vec2d* vel) :
	pos(u_vec2d(x, y)), radius(radius), color(*col), vel(*vel), mass(0) {}
Particle::Particle(float x, float y, float radius, u_Color* col, u_vec2d* vel, u_vec2d* acc) :
	pos(u_vec2d(x, y)), radius(radius), color(*col), vel(*vel), acc(*acc), mass(0) {}
void Particle::SetMass(float mas) {
	mass = mas;
}
//Particle Logics Definitions
bool Particle::Collided(Particle*& other) {
	float dst = powf(pos.x - other->pos.x, 2.f) + powf(pos.y - other->pos.y, 2.f);
	if (dst <= powf(radius + other->radius,2.f)) {
		return true;
	}
	return false;
}


//Particle Update
void Particle::Update(float dt) {
	pos = vel*dt + pos;
	vel = acc*dt + vel;
}

void u_ParticlesUpdate(std::vector<Particle*>& par, Boundary*& bound, float dt) {
	for (Particle*& p : par) {
		p->Update(dt);
		p->CollisionBorder(bound);
		u_CollisionParticle(p, par);
	}
}


//Collision Related
void Particle::CollisionBorder(Boundary*& b) {
	if (pos.x - radius <= b->x - b->width / 2) { //left border
		CollisionResponseBorder(-1, 0, b);
	}
	else if (pos.x + radius >= b->x + b->width / 2) {//right border
		CollisionResponseBorder(1, 0, b);
	}
	if (pos.y + radius >= b->y + b->height / 2) {//down border
		CollisionResponseBorder(0, 1, b);
	}
	else if (pos.y - radius <= b->y - b->height / 2) {//top border
		CollisionResponseBorder(0, -1, b);
	}
}

void u_CollisionParticle(Particle*& p,std::vector<Particle*>& par) {
	for (Particle*& p1 : par) {
		if (p != p1) {
			if (p->Collided(p1)) {
				p->CollisionResponse(p1);
			}
		}
	}
}


void Particle::CollisionResponse(Particle*& other) {
	//Correcting the intersected particles
	float theta = std::atan2f(pos.y - other->pos.y ,pos.x - other->pos.x);
	pos = other->pos + u_vec2d(cos(theta), sin(theta) ) * (radius + other->radius);

	//Actual Collission Response
	u_vec2d c1c2(pos.x - other->pos.x,pos.y - other->pos.y); // c1c2 is the vector from centre 1 to centre 2
	c1c2.normalize();
	u_vec2d n(c1c2.x * -1, c1c2.y * -1);
	float p = 2 * (vel - other->vel).dot(n) / (mass + other->mass);

	//final velocity after collision
	vel = vel - n * other->mass * p;
	other->vel = other->vel + n * mass * p;
}
void Particle::CollisionResponseBorder(short lr, short ud, Boundary*& b) {
	//Correcting the intersected particles
	const float _PI = 22.f/7.f;
	if (lr != 0) {
		float errorDst = -lr * (pos.x + lr*radius) + lr * (b->x + b->width / 2 * lr);
		pos.x = pos.x + lr * errorDst;
		vel.x = std::abs(vel.x) * -lr;
	}
	if (ud != 0) {
		float errorDst = -ud * (pos.y + ud * radius) + ud * (b->y + b->height / 2 * ud);
		pos.y = pos.y + ud * errorDst;
		vel.y = std::abs(vel.y) * -ud;
	}
}
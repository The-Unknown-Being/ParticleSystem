#pragma once
#include <vector>
//Enums
enum CollidedObject {
	LEFT = 0, DOWN, RIGHT, UP, OBJ, NONE
};


//just for color
class u_Color {
public:
	int r, g, b;
	u_Color(int r, int g, int b);
};

//Vector class
class u_vec2d {
public:
	float x, y;

	u_vec2d();
	u_vec2d(float x, float y);

	u_vec2d operator+ (u_vec2d other) {
		return u_vec2d(x + other.x, y + other.y);
	}
	u_vec2d operator+= (u_vec2d other) {
		return u_vec2d(x + other.x, y + other.y);
	}
	u_vec2d operator- (u_vec2d other) {
		return u_vec2d(x - other.x, y - other.y);
	}
	u_vec2d operator* (float other) {
		return u_vec2d(x * other, y * other);
	}
	u_vec2d operator/ (float other) {
		return u_vec2d(x / other, y / other);
	}
	float dot(const u_vec2d& other) const {
		return x * other.x + y * other.y;
	}

	float length() {

		return sqrtf(powf(x, 2.f) + powf(y, 2.f));
	}
	
	void normalize() {
		float dst = length();
		x /= dst;
		y /= dst;
	}
};
//Boundary Related
class Boundary {
public:
	float x, y, width, height, mass;

	Boundary(float x, float y, float width, float height, float mass);
};

//Particle Related
class Particle {
public:
	float radius, mass;
	u_vec2d pos , vel, acc;
	u_Color color;

	Particle(float x, float y);
	Particle(float x, float y, float radius);
	Particle(float x, float y, float radius, u_Color* col, u_vec2d* vel);
	Particle(float x, float y, float radius, u_Color* col, u_vec2d* vel, u_vec2d* acc);
	void Update(float dt);
	void CollisionBorder(Boundary*& b);
	bool Collided(Particle*& other);
	void CollisionResponse(Particle*& other);
	void CollisionResponseBorder(short lefRight, short upDown, Boundary*& b);
	void SetMass(float mas);
};
void u_CollisionParticle(Particle*& p, std::vector<Particle*>& par);
void u_ParticlesUpdate(std::vector<Particle*>& par, Boundary*& bound, float dt);
